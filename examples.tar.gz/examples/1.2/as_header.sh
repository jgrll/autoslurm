#!/bin/bash
#====================================================================
# Template Configuration Script
# Author: https://github.com/jgrll
# License: MIT License (see LICENSE file)
#
# This is a template script meant to be customized for specific
# cluster architectures and program configurations (see examples).
#====================================================================

echo "Entering $(basename "$0")" >&2

source "$1"

case "$CLUSTER" in
    "nest")
		cat <<EOF
#!/bin/bash
#SBATCH --nodes=$NODES
#SBATCH --ntasks-per-node=$NTASKS_PER_NODE
#SBATCH --cpus-per-task=$NCPUS_PER_TASK
#SBATCH --job-name=$JOB_NAME
#SBATCH --output=%x.o%j
#SBATCH --error=%x.o%j
#SBATCH --time=$TIME
#SBATCH --partition=$PARTITION

export OMP_NUM_THREADS=\${SLURM_CPUS_PER_TASK}
export OMP_PLACES=cores

EOF
        case "$PROGRAM" in
            "pw") # module for Quantum Espresso on 'nest' machine
                cat <<EOF
module purge
module load quantum-espresso/6.5/intel-19.0.3.199-intel-mpi
				
EOF
                ;;

			*)
				echo "Warning: Unknown program '$PROGRAM'" >&2
            	;;
		esac
		;;


    *)
        echo "Warning: Unknown cluster '$CLUSTER'" >&2
        case "$PROGRAM" in
            *)
                echo "Warning: Unknown program '$PROGRAM'" >&2
                ;;
        esac
		;;
esac

echo "Leaving $(basename "$0")" >&2
